#!/bin/bash
rm /start/installed
rm -R /home/ubuntu/data/geth/chaindata/
